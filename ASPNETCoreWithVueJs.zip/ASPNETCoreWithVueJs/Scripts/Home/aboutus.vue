<template>
    <div id="about">
        <h1>About Us - Vue</h1>
    </div>

</template>
<script>
    export default {
        name: "about-component"
    };
</script>