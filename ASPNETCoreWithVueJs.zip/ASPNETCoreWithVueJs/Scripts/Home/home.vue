<template>
    <div id="home">
        <h1>Home -Vue</h1>
    </div>

</template>
<script>
    export default {
        name: "login-component"
    };
</script>