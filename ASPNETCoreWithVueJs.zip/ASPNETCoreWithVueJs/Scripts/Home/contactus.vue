<template>
    <div id="contact">
        <h1>Contact us - Vue</h1>
    </div>

</template>
<script>
    export default {
        name: "contact-component"
    };
</script>